# TFF Skeleton-Based Action Recognition

PyTorch implementation with joint, bone, angular and velocity features, a 10-dimensional topological descriptor, Gaussian KDE filtering, three multi-scale spatiotemporal graph convolution blocks, auxiliary classification and repeated screening.

## Installation

```bash
pip install -r requirements.txt
```

## Data format

Use the NTU RGB+D 25-joint ordering, float32 coordinates and zero-based labels. Split the dataset according to the NTU60 or NTU120 evaluation protocol before training.

NPZ files contain:

| Key | Shape |
| --- | --- |
| x_train | (N_train, 3, T, 25, M) |
| y_train | (N_train,) |
| x_val | (N_val, 3, T, 25, M) |
| y_val | (N_val,) |

Separate NPY data and label files are also supported. Use zeros for missing persons, missing joints and padded frames. Preprocessing performs root translation and resampling to 300 frames.

## Training

```bash
python train.py --data data/ntu60.npz --classes 60 --output runs/ntu60
python train.py --data data/ntu120.npz --classes 120 --output runs/ntu120
```

For separate NPY files:

```bash
python train.py --data data/train.npy --labels data/train_labels.npy --val-data data/val.npy --val-labels data/val_labels.npy --classes 60
```

Default SGD momentum is 0.9. Training runs for 55 epochs on NTU60 and 60 epochs on NTU120. The learning rate is multiplied by 0.1 after epochs 35, 45 and 55. KDE is fitted on the training set only, with a default bandwidth of 0.1 and threshold of 0.3. Use `--kde-samples` to set the maximum reference samples per class. Use `--density-mode density` for conditional density thresholds or `posterior` for normalized class probability thresholds.

Training saves `model.pt` and `config.json`. When validation data is provided, it also saves `metrics.json`.

## Inference

```bash
python predict.py --checkpoint runs/ntu60/model.pt --input data/sample.npy --output predictions.json
python predict.py --checkpoint runs/ntu60/model.pt --input data/sample.npy --prefix-frames 60
```

Input is an NPY file with shape `(3,T,25,M)` or `(N,3,T,25,M)`. Output contains zero-based class indices, NTU action IDs, filtering status and screening rounds. Use `--no-repeat` to disable repeated screening or `--device cpu` to run on the CPU.
