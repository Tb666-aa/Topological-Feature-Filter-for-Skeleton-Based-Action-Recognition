import math
import torch
from torch import nn
from .features import SkeletonFeatures, TopologicalFeatures
from .graph import multiscale_adjacency
from .kde import GaussianKDE


class SpatialMultiScaleGCN(nn.Module):
    def __init__(self, cin, cout, scales=3):
        super().__init__()
        self.register_buffer("adjacency", multiscale_adjacency(scales))
        self.mask = nn.Parameter(torch.zeros_like(self.adjacency))
        self.project = nn.Conv2d(cin * scales, cout, 1, bias=False)
        self.bn = nn.BatchNorm2d(cout)

    def forward(self, x):
        y = torch.einsum("nctv,kvw->nkctw", x, self.adjacency + self.mask)
        y = y.reshape(x.shape[0], -1, x.shape[2], x.shape[3])
        return self.bn(self.project(y))


class TemporalMultiBranchConv(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        branch_channels = math.ceil(cout / 7)

        def projection():
            return [nn.Conv2d(cin, branch_channels, 1, bias=False),
                    nn.BatchNorm2d(branch_channels), nn.ReLU(inplace=True)]

        branches = []
        for dilation in (1, 2, 3, 4):
            branches.append(nn.Sequential(*projection(), nn.Conv2d(
                branch_channels, branch_channels, (3, 1), stride=(stride, 1),
                padding=(dilation, 0), dilation=(dilation, 1), bias=False),
                nn.BatchNorm2d(branch_channels)))
        branches.append(nn.Sequential(*projection(), nn.MaxPool2d((3, 1), (stride, 1), (1, 0)),
                                      nn.BatchNorm2d(branch_channels)))
        branches.append(nn.Sequential(*projection(), nn.AvgPool2d((3, 1), (stride, 1), (1, 0)),
                                      nn.BatchNorm2d(branch_channels)))
        branches.append(nn.Sequential(nn.Conv2d(cin, branch_channels, 1, (stride, 1), bias=False),
                                      nn.BatchNorm2d(branch_channels)))
        self.branches = nn.ModuleList(branches)
        self.merge = nn.Sequential(nn.Conv2d(7 * branch_channels, cout, 1, bias=False), nn.BatchNorm2d(cout))

    def forward(self, x):
        return self.merge(torch.cat([branch(x) for branch in self.branches], dim=1))


class SpatioTemporalBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.spatial = SpatialMultiScaleGCN(cin, cout)
        self.temporal = TemporalMultiBranchConv(cout, cout, stride)
        self.residual = nn.Identity() if cin == cout and stride == 1 else nn.Sequential(
            nn.Conv2d(cin, cout, 1, (stride, 1), bias=False), nn.BatchNorm2d(cout))
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.relu(self.temporal(self.relu(self.spatial(x))) + self.residual(x))


class TFFModel(nn.Module):
    def __init__(self, classes=60, channels=(64, 128, 256), bandwidth=0.1,
                 threshold=0.3, max_samples=256, topk=5, density_mode="density"):
        super().__init__()
        if not 0 < threshold or topk < 1 or density_mode not in ("density", "posterior"):
            raise ValueError("invalid filtering configuration")
        self.classes = classes
        self.threshold, self.topk, self.density_mode = threshold, topk, density_mode
        self.features = SkeletonFeatures()
        self.topology = TopologicalFeatures()
        self.kde = GaussianKDE(classes, bandwidth=bandwidth, max_samples=max_samples)
        self.input_projection = nn.Sequential(nn.Conv2d(14, channels[0], 1, bias=False),
                                              nn.BatchNorm2d(channels[0]), nn.ReLU(inplace=True))
        self.blocks = nn.Sequential(SpatioTemporalBlock(channels[0], channels[0]),
                                    SpatioTemporalBlock(channels[0], channels[1], 2),
                                    SpatioTemporalBlock(channels[1], channels[2], 2))
        self.classifier = nn.Linear(channels[2], classes)
        self.auxiliary = nn.Sequential(nn.Linear(10, 64), nn.ReLU(), nn.Linear(64, classes))

    def backbone(self, x):
        present = x.abs().sum((1, 2, 3)) > 0
        x = self.features(x)
        n, c, t, v, m = x.shape
        x = x.permute(0, 4, 1, 2, 3).reshape(n * m, c, t, v)
        x = self.blocks(self.input_projection(x)).mean((2, 3)).reshape(n, m, -1)
        x = (x * present.unsqueeze(-1)).sum(1) / present.sum(1, keepdim=True).clamp_min(1)
        return self.classifier(x)

    def forward(self, x):
        return self.backbone(x), self.auxiliary(self.topology(x))

    @torch.no_grad()
    def predict(self, x, repeated=True, prefix_frames=0):
        """Topology screening precedes the STBs; ambiguous samples are retained."""
        self.eval()
        descriptor = self.topology(x)
        log_density = self.kde.log_density(descriptor)
        topology_logp = log_density.log_softmax(-1)
        score = log_density if self.density_mode == "density" else topology_logp
        candidate = log_density.argmax(-1)
        accepted = score.gather(1, candidate[:, None]).squeeze(1) >= math.log(self.threshold)
        logits = self.backbone(x)
        logp = logits.log_softmax(-1)
        prediction = logits.argmax(-1)
        rounds = torch.ones_like(prediction)
        if repeated:
            pending = ~accepted
            # Verify alternative candidates against the lightweight auxiliary classifier.
            auxiliary_logp = self.auxiliary(descriptor).log_softmax(-1)
            ranking = (topology_logp + auxiliary_logp).argsort(-1, descending=True)
            for step in range(min(self.topk, self.classes)):
                c = ranking[:, step]
                match = pending & (score.gather(1, c[:, None]).squeeze(1) >= math.log(self.threshold))
                prediction[match] = c[match]
                rounds[pending] = step + 1
                accepted |= match
                pending &= ~match
            # Final verification combines the backbone and auxiliary predictions.
            combined = logp + auxiliary_logp
            if prefix_frames > 0 and pending.any():
                length = min(prefix_frames, x.shape[2])
                combined[pending] += self.backbone(x[pending, :, :length]).log_softmax(-1)
            prediction[pending] = combined[pending].argmax(-1)
        return {"prediction": prediction, "logits": logits, "accepted": accepted,
                "rounds": rounds, "topology_probability": topology_logp.exp()}
