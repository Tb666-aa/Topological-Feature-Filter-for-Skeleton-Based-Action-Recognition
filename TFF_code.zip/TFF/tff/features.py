import torch
from torch import nn
from .graph import PARENTS


def temporal_difference(x):
    return torch.cat((x[:, :, 1:] - x[:, :, :-1], torch.zeros_like(x[:, :, :1])), dim=2)


def angle(x, vertex, endpoint1, endpoint2):
    a = x[..., endpoint1, :] - x[..., vertex, :]
    b = x[..., endpoint2, :] - x[..., vertex, :]
    cosine = (a * b).sum(1) / (a.norm(dim=1) * b.norm(dim=1)).clamp_min(1e-8)
    valid = (a.norm(dim=1) > 1e-8) & (b.norm(dim=1) > 1e-8)
    return cosine.clamp(-1, 1), valid


def smooth_angles(theta):
    # theta: N,T,V,M; replace temporal jumps larger than 45 degrees.
    if theta.shape[1] < 3:
        return theta
    padded = torch.cat((theta[:, :1], theta, theta[:, -1:]), dim=1)
    median = padded.unfold(1, 3, 1).median(dim=-1).values
    delta = torch.cat((torch.zeros_like(theta[:, :1]), theta[:, 1:] - theta[:, :-1]), dim=1)
    return torch.where(delta.abs() > torch.pi / 4, median, theta)


class SkeletonFeatures(nn.Module):
    """Joint, bone, angular geometry, and their temporal differences."""
    def __init__(self):
        super().__init__()
        self.register_buffer("parents", torch.tensor(PARENTS))
        self.register_buffer("endpoints1", torch.full((25,), 7, dtype=torch.long))
        self.register_buffer("endpoints2", torch.full((25,), 11, dtype=torch.long))

    def forward(self, x):
        bone = x.index_select(3, self.parents) - x
        a = x.index_select(3, self.endpoints1) - x
        b = x.index_select(3, self.endpoints2) - x
        valid = (a.norm(dim=1) > 1e-8) & (b.norm(dim=1) > 1e-8)
        cosine = ((a * b).sum(1) / (a.norm(dim=1) * b.norm(dim=1)).clamp_min(1e-8)).clamp(-1, 1)
        theta = smooth_angles(cosine.acos())
        age = torch.where(valid, 1 - theta.cos(), 0).unsqueeze(1)
        return torch.cat((x, bone, age, temporal_difference(x),
                          temporal_difference(bone), temporal_difference(age)), dim=1)


class TopologicalFeatures(nn.Module):
    """Sequence-level angle, non-adjacent distance, and bone-ratio descriptors."""
    angle_triplets = ((5, 4, 6), (9, 8, 10), (13, 12, 14), (17, 16, 18))
    distance_pairs = ((7, 11), (7, 3), (11, 3), (15, 19))
    ratio_pairs = (((4, 5), (5, 6)), ((8, 9), (9, 10)))

    @staticmethod
    def average(values, mask):
        mask = mask.to(values.dtype)
        return (values * mask).sum((1, 2)) / mask.sum((1, 2)).clamp_min(1)

    def forward(self, x):
        present = x.abs().sum(1) > 0  # N,T,V,M
        output = []
        for u, a, b in self.angle_triplets:
            cosine, valid = angle(x, u, a, b)
            mask = valid & present[:, :, u] & present[:, :, a] & present[:, :, b]
            output.append(self.average(cosine.acos(), mask))
        for a, b in self.distance_pairs:
            distance = (x[..., a, :] - x[..., b, :]).norm(dim=1)
            output.append(self.average(distance, present[:, :, a] & present[:, :, b]))
        for (a, b), (c, d) in self.ratio_pairs:
            la = (x[..., a, :] - x[..., b, :]).norm(dim=1)
            lb = (x[..., c, :] - x[..., d, :]).norm(dim=1)
            mask = present[:, :, a] & present[:, :, b] & present[:, :, c] & present[:, :, d]
            output.append((la * mask).sum((1, 2)) / (lb * mask).sum((1, 2)).clamp_min(1e-8))
        return torch.stack(output, dim=-1)
