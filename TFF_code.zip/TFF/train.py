import argparse
import json
import random
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from tff import TFFModel
from tff.data import SkeletonDataset


@torch.no_grad()
def fit_kde(model, loader, device, seed):
    model.eval()
    features, labels = [], []
    for x, y in loader:
        features.append(model.topology(x.to(device)))
        labels.append(y.to(device))
    model.kde.fit(torch.cat(features), torch.cat(labels), seed)


@torch.no_grad()
def evaluate(model, loader, device):
    correct = filtered = total = 0
    for x, y in loader:
        y = y.to(device)
        result = model.predict(x.to(device))
        correct += (result["logits"].argmax(-1) == y).sum().item()
        filtered += (result["prediction"] == y).sum().item()
        total += len(y)
    return {"backbone_accuracy": correct / total, "tff_accuracy": filtered / total}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--labels")
    parser.add_argument("--val-data")
    parser.add_argument("--val-labels")
    parser.add_argument("--classes", type=int, choices=(60, 120), default=60)
    parser.add_argument("--epochs", type=int)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--frames", type=int, default=300)
    parser.add_argument("--lr", type=float, default=0.1)
    parser.add_argument("--weight-decay", type=float, default=0.0005)
    parser.add_argument("--aux-weight", type=float, default=0.2)
    parser.add_argument("--bandwidth", type=float, default=0.1)
    parser.add_argument("--threshold", type=float, default=0.3)
    parser.add_argument("--kde-samples", type=int, default=256)
    parser.add_argument("--topk", type=int, default=5)
    parser.add_argument("--density-mode", choices=("density", "posterior"), default="density")
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--output", default="runs/tff")
    args = parser.parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    device = torch.device(args.device)
    train_set = SkeletonDataset(args.data, "train", args.frames, args.labels)
    if train_set.labels.min() < 0 or train_set.labels.max() >= args.classes:
        raise ValueError("Labels must be zero-based and smaller than --classes")
    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True,
                              num_workers=args.workers)
    reference_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=False,
                                  num_workers=args.workers)
    val_loader = None
    if args.val_data or Path(args.data).suffix == ".npz":
        val_set = SkeletonDataset(args.val_data or args.data, "val", args.frames, args.val_labels)
        val_loader = DataLoader(val_set, batch_size=args.batch_size, num_workers=args.workers)
    config = dict(classes=args.classes, bandwidth=args.bandwidth, threshold=args.threshold,
                  max_samples=args.kde_samples, topk=args.topk, density_mode=args.density_mode)
    model = TFFModel(**config).to(device)
    optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9,
                                weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[35, 45, 55], gamma=0.1)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    (output / "config.json").write_text(json.dumps(vars(args), indent=2), encoding="utf-8")
    epochs = args.epochs or (55 if args.classes == 60 else 60)
    for epoch in range(epochs):
        model.train()
        total_loss = total = 0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits, auxiliary = model(x)
            loss = F.cross_entropy(logits, y) + args.aux_weight * F.cross_entropy(auxiliary, y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(y)
            total += len(y)
        scheduler.step()
        print(json.dumps({"epoch": epoch + 1, "loss": total_loss / total,
                          "lr": scheduler.get_last_lr()[0]}), flush=True)
    fit_kde(model, reference_loader, device, args.seed)
    torch.save({"model": model.state_dict(), "config": config, "frames": args.frames,
                "epoch": epochs}, output / "model.pt")
    if val_loader is not None:
        metrics = evaluate(model, val_loader, device)
        (output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
        print(json.dumps(metrics))


if __name__ == "__main__":
    main()
